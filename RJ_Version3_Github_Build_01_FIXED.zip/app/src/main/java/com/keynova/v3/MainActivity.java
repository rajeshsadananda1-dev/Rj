package com.keynova.v3;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "keynova";
    private static final String ACTIVATED = "activated";
    private static final String ACTIVATION_CODE = "RJ8050";

    private EditText serialInput;
    private TextView v3Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView(R.layout.activity_main);

        if (!isActivated()) {
            showActivationDialog();
        }

        TextView dateText = findViewById(R.id.dateText);
        serialInput = findViewById(R.id.serialInput);
        v3Result = findViewById(R.id.v3Result);
        Button generate = findViewById(R.id.generateButton);

        dateText.setText("Date: " + new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));

        serialInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                v.postDelayed(() -> {
                    v.requestRectangleOnScreen(
                        new android.graphics.Rect(0, 0, v.getWidth(), v.getHeight()), true);
                }, 250);
            }
        });

        generate.setOnClickListener(v -> generateV3());
    }

    private boolean isActivated() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(ACTIVATED, false);
    }

    private void showActivationDialog() {
        final EditText input = new EditText(this);
        input.setHint("Activation code");
        input.setSingleLine(true);
        input.setInputType(1);

        new AlertDialog.Builder(this)
            .setTitle("Activate KeyNova")
            .setMessage("Enter the one-time activation code")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Activate", (dialog, which) -> {
                if (ACTIVATION_CODE.equals(input.getText().toString().trim())) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean(ACTIVATED, true).apply();
                    Toast.makeText(this, "Activated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Invalid activation code", Toast.LENGTH_SHORT).show();
                    showActivationDialog();
                }
            })
            .show();
    }

    private void generateV3() {
        String serial = serialInput.getText().toString().trim();
        if (serial.length() != 5) {
            serialInput.setError("Enter exactly 5 digits");
            serialInput.requestFocus();
            return;
        }

        /*
         * IMPORTANT:
         * The exact finalized V3 formula from the earlier app/project is not
         * present in the currently available source context. Do not replace
         * this with a guessed formula.
         *
         * Insert the existing V3 calculation here and return its 5-digit result.
         */
        String result = existingV3Formula(serial);
        v3Result.setText(result);
    }

    private String existingV3Formula(String serial) {
        // Placeholder so the GitHub project builds.
        // Replace this method with the exact existing V3 algorithm.
        return "";
    }
}
