# KeyNova V3

Android app project for the KeyNova V3 layout.

## Included
- KeyNova app name and icon
- Black UI
- One-time activation code: `RJ8050`
- 5-digit serial input
- Generate button
- V3.0 password result area
- Blank V4.0 password area for future use
- Designed by Rj footer
- Keyboard-safe scrolling using `adjustResize`

## Important
The exact existing V3 password formula was not available in the source context used to create this GitHub-ready project, so `existingV3Formula()` is intentionally left as a placeholder. Do not use a guessed formula if exact V3 results are required.

## Build on GitHub
Push this folder to a GitHub repository. The included GitHub Actions workflow builds a debug APK and publishes it under the workflow run's Artifacts.
