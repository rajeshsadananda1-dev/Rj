package com.rj.password

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var serialInput: EditText
    private lateinit var result: TextView
    private lateinit var dateText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(40, 60, 40, 40)
        }

        val title = TextView(this).apply {
            text = "RJ"
            textSize = 32f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Version 3 • 5-Digit Password Generator"
            textSize = 16f
            gravity = Gravity.CENTER
        }

        dateText = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        }
        updateDateText()

        serialInput = EditText(this).apply {
            hint = "Enter 5-digit serial"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            maxLines = 1
            maxLength = 5
        }

        val generate = Button(this).apply {
            text = "GENERATE PASSWORD"
            setOnClickListener { generatePassword() }
        }

        result = TextView(this).apply {
            text = "Password: -----"
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 20)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(dateText)
        root.addView(serialInput,
            LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 32 })
        root.addView(generate,
            LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 20 })
        root.addView(result)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        updateDateText()
    }

    private fun updateDateText() {
        if (!::dateText.isInitialized) return
        val c = Calendar.getInstance()
        dateText.text = String.format(
            "Date: %02d-%02d-%04d",
            c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.MONTH) + 1,
            c.get(Calendar.YEAR)
        )
    }

    /**
     * Exact Version 3 calculation reproduced from the decompiled MainActivity.calNewest().
     * The original uses android.text.format.Time.setToNow(), local device time,
     * Sunday=7, and day-of-year starting at 1.
     */
    private fun calculateVersion3(serial: String): String {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH) + 1
        val day = c.get(Calendar.DAY_OF_MONTH)

        // Calendar: Sunday=1 ... Saturday=7. Convert to original Time.weekDay
        // convention: Sunday=7, Monday=1 ... Saturday=6.
        val calendarWeekDay = c.get(Calendar.DAY_OF_WEEK)
        val weekDay = if (calendarWeekDay == Calendar.SUNDAY) 7 else calendarWeekDay - 1
        val dayOfYear = c.get(Calendar.DAY_OF_YEAR)

        val a = serial[0] - '0'
        val b = serial[1] - '0'
        val cc = serial[2] - '0'
        val d = serial[3] - '0'
        val e = serial[4] - '0'

        // This is equivalent to the original decompiled j16 digit-summing code.
        val digitSum = a + b + cc + d + e
        val sumCube = digitSum.toLong() * digitSum * digitSum

        val ace = ("${serial[0]}${serial[2]}${serial[4]}").toLong()
        val eca = ("${serial[4]}${serial[2]}${serial[0]}").toLong()

        val intermediate =
            (month.toLong() * day) +
            year.toLong() +
            sumCube +
            (weekDay.toLong() * weekDay) +
            dayOfYear.toLong() +
            (ace * eca)

        val value = 36873L xor intermediate

        // Original: take the lowest five decimal digits, then reverse them.
        val lastFive = Math.floorMod(value, 100000L).toString().padStart(5, '0')
        return lastFive.reversed()
    }

    private fun generatePassword() {
        val s = serialInput.text.toString()
        if (!s.matches(Regex("\\d{5}"))) {
            serialInput.error = "Enter exactly 5 digits"
            return
        }

        result.text = "Password: ${calculateVersion3(s)}"
        updateDateText()
    }
}
