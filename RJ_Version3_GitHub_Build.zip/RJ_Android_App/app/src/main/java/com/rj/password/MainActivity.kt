package com.rj.password

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    companion object {
        private const val ACTIVATION_PASSWORD = "RJ8050"
        private const val PREFS_NAME = "rj_settings"
        private const val KEY_ACTIVATED = "activated"
        private const val BLACK = Color.BLACK
        private const val WHITE = Color.WHITE
        private const val DARK_GRAY = 0xFF1E1E1E.toInt()
        private const val GRAY = 0xFFAAAAAA.toInt()
    }

    private lateinit var serialInput: EditText
    private lateinit var result: TextView
    private lateinit var dateText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BLACK
        window.navigationBarColor = BLACK
        window.decorView.systemUiVisibility = 0

        if (getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_ACTIVATED, false)) {
            showMainScreen()
        } else {
            showActivationScreen()
        }
    }

    private fun showActivationScreen() {
        val root = baseRoot()

        val title = textView("RJ", 34f, WHITE).apply {
            gravity = Gravity.CENTER
        }
        val subtitle = textView("Activation", 20f, WHITE).apply {
            gravity = Gravity.CENTER
        }
        val info = textView("Enter activation password to continue", 15f, GRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }

        val passwordInput = EditText(this).apply {
            hint = "Activation password"
            setHintTextColor(GRAY)
            setTextColor(WHITE)
            textSize = 18f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(24, 16, 24, 16)
            background = roundedBackground(DARK_GRAY)
        }

        val activate = Button(this).apply {
            text = "ACTIVATE"
            textSize = 15f
            setTextColor(WHITE)
            background = roundedBackground(DARK_GRAY)
            setOnClickListener {
                if (passwordInput.text.toString() == ACTIVATION_PASSWORD) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_ACTIVATED, true)
                        .apply()
                    showMainScreen()
                } else {
                    passwordInput.error = "Invalid activation password"
                    passwordInput.setText("")
                }
            }
        }

        root.addView(title, lpWrap().apply { bottomMargin = 8 })
        root.addView(subtitle, lpWrap().apply { bottomMargin = 12 })
        root.addView(info, lpWrap().apply { bottomMargin = 12 })
        root.addView(passwordInput, lpCentered().apply { bottomMargin = 18 })
        root.addView(activate, lpCentered())

        setContentView(root)
    }

    private fun showMainScreen() {
        val root = baseRoot()

        val title = textView("RJ", 34f, WHITE).apply {
            gravity = Gravity.CENTER
        }
        val subtitle = textView("Version 3", 20f, WHITE).apply {
            gravity = Gravity.CENTER
        }

        dateText = textView("", 14f, GRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }
        updateDateText()

        serialInput = EditText(this).apply {
            hint = "Enter 5-digit serial"
            setHintTextColor(GRAY)
            setTextColor(WHITE)
            textSize = 20f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            maxLines = 1
            gravity = Gravity.CENTER
            filters = arrayOf(android.text.InputFilter.LengthFilter(5))
            setPadding(24, 16, 24, 16)
            background = roundedBackground(DARK_GRAY)
        }

        val generate = Button(this).apply {
            text = "GENERATE"
            textSize = 15f
            setTextColor(WHITE)
            background = roundedBackground(DARK_GRAY)
            setOnClickListener { generatePassword() }
        }

        result = textView("Version 3 Password\n-----", 30f, WHITE).apply {
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 20)
        }

        root.addView(title, lpWrap().apply { bottomMargin = 6 })
        root.addView(subtitle, lpWrap().apply { bottomMargin = 8 })
        root.addView(dateText, lpWrap().apply { bottomMargin = 28 })
        root.addView(serialInput, lpCentered().apply { bottomMargin = 16 })
        root.addView(generate, lpCentered().apply { bottomMargin = 16 })

        // All main-screen content stays centered.
        root.addView(result, lpWrap().apply { bottomMargin = 0 })

        setContentView(root)
    }

    private fun baseRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setBackgroundColor(BLACK)
        setPadding(40, 40, 40, 40)
    }

    private fun textView(value: String, size: Float, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
    }

    private fun lpWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun lpMatch() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun lpCentered(): LinearLayout.LayoutParams {
        val width = (300 * resources.displayMetrics.density).toInt()
        return LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun roundedBackground(fill: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = 18f
        setStroke(1, 0xFF444444.toInt())
    }

    override fun onResume() {
        super.onResume()
        if (::dateText.isInitialized) updateDateText()
    }

    private fun updateDateText() {
        if (!::dateText.isInitialized) return
        val c = Calendar.getInstance()
        dateText.text = String.format(
            "Date: %02d-%02d-%04d",
            c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.MONTH) + 1,
            c.get(Calendar.YEAR)
        )
    }

    /** Exact Version 3 calculation reproduced from the decompiled MainActivity.calNewest(). */
    private fun calculateVersion3(serial: String): String {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH) + 1
        val day = c.get(Calendar.DAY_OF_MONTH)

        // Original Time.weekDay: Sunday=7, Monday=1 ... Saturday=6.
        val calendarWeekDay = c.get(Calendar.DAY_OF_WEEK)
        val weekDay = if (calendarWeekDay == Calendar.SUNDAY) 7 else calendarWeekDay - 1
        val dayOfYear = c.get(Calendar.DAY_OF_YEAR)

        val a = serial[0] - '0'
        val b = serial[1] - '0'
        val cc = serial[2] - '0'
        val d = serial[3] - '0'
        val e = serial[4] - '0'

        val digitSum = a + b + cc + d + e
        val sumCube = digitSum.toLong() * digitSum * digitSum

        val ace = ("${serial[0]}${serial[2]}${serial[4]}").toLong()
        val eca = ("${serial[4]}${serial[2]}${serial[0]}").toLong()

        val intermediate =
            (month.toLong() * day) +
            year.toLong() +
            sumCube +
            (weekDay.toLong() * weekDay) +
            dayOfYear.toLong() +
            (ace * eca)

        val value = 36873L xor intermediate
        val lastFive = Math.floorMod(value, 100000L).toString().padStart(5, '0')
        return lastFive.reversed()
    }

    private fun generatePassword() {
        val s = serialInput.text.toString()
        if (!s.matches(Regex("\\d{5}"))) {
            serialInput.error = "Enter exactly 5 digits"
            return
        }

        result.text = "Version 3 Password\n${calculateVersion3(s)}"
        updateDateText()
    }
}
