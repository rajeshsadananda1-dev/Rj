# RJ Version 3 — Phone-only APK build

This project is prepared for GitHub Actions. You do not need a PC or Android Studio.

## On your Android phone

1. Create/sign in to a GitHub account.
2. Create a **new repository** (for example `RJ-Version3`).
3. Upload **all files and folders inside this project** to the repository root.
4. Open the repository's **Actions** tab.
5. Select **Build RJ APK**.
6. Tap **Run workflow** and confirm.
7. Wait for the workflow to finish with a green check.
8. Open that workflow run and scroll to **Artifacts**.
9. Download **RJ-Version3-APK**. Inside it is `app-debug.apk`.
10. Install the APK on your Android phone. If Android asks, allow installation from that source.

The workflow uses JDK 17 and Gradle 8.9 and builds the existing RJ Android project. GitHub Actions runs the build on a hosted Ubuntu machine, so no PC is required.
