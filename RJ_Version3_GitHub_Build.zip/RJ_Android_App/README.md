# RJ — Version 3 Password Generator

This Android project implements the Version 3 (`calNewest`) calculation recovered from the decompiled PSW4+ APK.

## Exact calculation

For serial `ABCDE`, using the device's current local date/time:

- `Y` = current year
- `M` = current month (1–12)
- `D` = current day of month
- `W` = weekday where Sunday=7, Monday=1, ..., Saturday=6
- `N` = day of year (1–366)
- `S` = A+B+C+D+E
- `ACE` = digits 1,3,5
- `ECA` = ACE reversed

Then:

`V = 36873 XOR ((M×D) + Y + S³ + W² + N + (ACE×ECA))`

The displayed password is the lowest five decimal digits of `V`, zero-padded to five digits, then reversed.

The app uses the device's current local date, matching the original `Time.setToNow()` behavior.

## Verified examples for 19-09-2026

- 41805 → 03202
- 21212 → 62632
- 09899 → 74496
- 35894 → 73014
- 89486 → 53403

## Build

Open this project in Android Studio and build the APK with **Build > Build APK(s)**.
